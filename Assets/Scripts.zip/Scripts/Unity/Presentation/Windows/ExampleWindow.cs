using Unity.Infrastructure.Windows;

namespace Unity.Presentation.Windows
{
	[Window(nameof(ExampleWindow))]
	public class ExampleWindow : WindowBase
	{

	}
}