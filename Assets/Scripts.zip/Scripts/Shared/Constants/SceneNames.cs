﻿namespace Shared.Constants
{
   public static class SceneNames
   {
      public const string MainMenuScene = nameof(MainMenuScene);
      public const string GameScene = nameof(GameScene);
      public const string InitGameScene = nameof(InitGameScene);
      
   }
}